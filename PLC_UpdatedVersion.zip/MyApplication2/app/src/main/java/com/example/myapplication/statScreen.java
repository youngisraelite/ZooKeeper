package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


public class statScreen extends AppCompatActivity {
    private TextView updateAccCounter;
    private Button statToHomeButton;
    String txt;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stat_screen);
        updateAccCounter = (TextView) findViewById(R.id.accidentCounter);
        statToHomeButton = (Button) findViewById(R.id.statToHome);

        //sets AccValue equal to the value stored stored in shared preferences and
        final SharedPreferences mSharedPreference= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        Integer AccValue =(mSharedPreference.getInt("ACC_VALUE", 0));
        //sets the textview equal to accValue ie updates number of accidents value
        updateAccCounter.setText(txt.valueOf(AccValue));

        //send user back home on button click
        statToHomeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(statScreen.this, homeScreen.class);
                startActivity(in);
            }
        });

    }
}
