package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

import pl.droidsonroids.gif.GifImageView;

public class finishScreen extends AppCompatActivity {
    private Button takeBreakButton;
    private Button skipBreakButton;
    private Button finishToHomeButton;
    private GifImageView dance;
    private GifImageView collectOnClickCoin;
    int counter = 0 ;
    int coins ;
    private TextView counterTxt;
    String txt="";
    private TextView cliclToCollectTxt;
    Boolean clicked = false;
    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;
    private MediaPlayer coinSound;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_first);
        takeBreakButton = (Button) findViewById(R.id.coffeBreak);
        skipBreakButton = (Button) findViewById(R.id.KeepDriving);
        finishToHomeButton = (Button) findViewById(R.id.finishToHome);
        collectOnClickCoin = (GifImageView) findViewById(R.id.spiningCoin);
        counterTxt = (TextView) findViewById(R.id.coinCount);
        cliclToCollectTxt = (TextView) findViewById(R.id.clickToCollectTxt);
        coinSound = MediaPlayer.create(this, R.raw.coinsound);

        //deadass some redundant code here but it works so don't fucking touch it cause it fucking sucks and is very annoying
         prefs = PreferenceManager.getDefaultSharedPreferences(this);
         editor = prefs.edit();

        final SharedPreferences mSharedPreference= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        Integer value =(mSharedPreference.getInt("COINS_VALUE", 0));
        counterTxt.setText(txt.valueOf(value));



        //updates coin count by 10 when coin is clicked
        collectOnClickCoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { ;
                increment();
                collectOnClickCoin.setVisibility(View.GONE);
                cliclToCollectTxt.setVisibility(View.GONE);
                clicked = true;
                coinSound.start();

            }
        });


        //sends user to home on button click
        finishToHomeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                clickyOrNoClicky();
            }
        });

    //sends user to driving screen
        skipBreakButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!clicked) {
                    increment();
                    Intent in = new Intent(finishScreen.this, drivingScreen.class);
                    startActivity(in);
                }   else {
                    Intent in = new Intent(finishScreen.this, drivingScreen.class);
                    startActivity(in);
                }
            }
        });

    //sends user to break screen
        takeBreakButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!clicked) {
                    increment();
                    Intent in = new Intent(finishScreen.this, breakScreen.class);
                    startActivity(in);
                }   else {
                    Intent in = new Intent(finishScreen.this, breakScreen.class);
                    startActivity(in);
                }
            }
        });
    }

    //updates and stores coin value by ten
    public void increment(){
        coins = prefs.getInt("COINS_VALUE",0);
        counter = + 10;
        coins = coins + counter;
        editor.putInt("COINS_VALUE", coins);
        counterTxt.setText(txt.valueOf(coins));
        editor.apply();
        editor.commit();
    }

    public void clickyOrNoClicky(){
        if (!clicked) {
            increment();
            Intent in = new Intent(finishScreen.this, homeScreen.class);
            startActivity(in);
        }   else {
                Intent in = new Intent(finishScreen.this, homeScreen.class);
                startActivity(in);
            }
    }

    // *shrugs* *cries*
    /*public void tohome(){
        Intent in = new Intent(finishScreen.this, homeScreen.class);
        in.putExtra("t", counter);
        startActivity(in);
    } */
}