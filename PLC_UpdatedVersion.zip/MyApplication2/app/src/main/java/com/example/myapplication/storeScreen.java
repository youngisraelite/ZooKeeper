package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.preference.PreferenceManager;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.view.animation.Animation;
import androidx.appcompat.app.AppCompatActivity;


public class storeScreen extends AppCompatActivity {
    private Button toHome;
    private Button unlock;
    private Button next;

    private TextView counterTxt2;
    int coins;
    int intCost;
    int balance;
    int value;
    String txt = "";
    private ImageSwitcher is;
    private TextSwitcher ts;




    int[] imageSwitcherImages = {R.drawable.pandadriving1, R.drawable.pandadriving2, R.drawable.pandadriving3};
    String [] storeCostStrings = {"Cost: 10 Coins", "Cost: 20 Coins", "Cost: 30 Coins"};
    int switcherImageLength = imageSwitcherImages.length;
    int counter = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.store_screen);

        toHome = findViewById(R.id.storeToHomeButton);
        unlock = findViewById(R.id.unlockButton);
        counterTxt2 = findViewById(R.id.coinCounter2);
        is = findViewById(R.id.imageSwitcher);
        next = findViewById(R.id.rightBtn);
        ts = findViewById(R.id.costSwitcher);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = prefs.edit();

        ts.setFactory(() -> {
            TextView costs = new TextView(storeScreen.this);
            costs.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            costs.setTextSize(24);
            return costs;
        });

        //Text Switcher Animations
        Animation textIn = AnimationUtils.loadAnimation(this,android.R.anim.slide_in_left);
        Animation textOut = AnimationUtils.loadAnimation(this, android.R.anim.slide_out_right);
        ts.setInAnimation(textIn);
        ts.setOutAnimation(textOut);
        ts.setCurrentText(storeCostStrings[0]);


        is.setFactory(() -> {
            ImageView myView = new ImageView(getApplicationContext());
            myView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            myView.setLayoutParams(new ImageSwitcher.LayoutParams(600 , 600));
            myView.setImageResource(R.drawable.pandadriving1);
            return myView;
        });

        //Image Switcher Animations
        Animation aniOut = AnimationUtils.loadAnimation(this, android.R.anim.slide_out_right);
        Animation aniIn = AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left);
        is.setInAnimation(aniIn);
        is.setOutAnimation(aniOut);

        next.setOnClickListener(v -> {
            counter++;
            if (counter == switcherImageLength) {
                counter = 0;
            }
            is.setImageResource(imageSwitcherImages[counter]);
            ts.setText(storeCostStrings[counter]);

        });

        final SharedPreferences mSharedPreference= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        Integer value =(mSharedPreference.getInt("COINS_VALUE", 0));

        counterTxt2.setText(txt.valueOf(value));
        Intent min = getIntent();
        coins = min.getIntExtra("t", 0);


        toHome.setOnClickListener(view -> {
            Intent in = new Intent(storeScreen.this, homeScreen.class);
            startActivity(in);
        });
        unlock.setOnClickListener(view -> {

            TextView unlockTxt = findViewById(R.id.purchaseComplete);

            TextView cost = (TextView) ts.getCurrentView();
            String currentCost = cost.getText().toString();
            currentCost = currentCost.replaceAll("[^\\d]", " ");
            currentCost = currentCost.trim();
            int intCost = Integer.parseInt(currentCost);


            CountDownTimer textTimer = new CountDownTimer(2000,1000) {
                @Override
                public void onTick(long l) { }

                @Override
                public void onFinish() {
                unlockTxt.setText("");
                }
            }.start();

            if(value >= intCost) {
                String text = "Purchase Completed";
                SpannableString ss = new SpannableString(text);
                StyleSpan boldSpan = new StyleSpan(Typeface.BOLD);
                ss.setSpan(boldSpan, 0, 18, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                unlockTxt.setText(ss);
                //purchase(prefs, editor);
            }
            else{
                String noPurchase= "Not enough coins";
                SpannableString ss2 = new SpannableString(noPurchase);
                unlockTxt.setText(ss2);
            }


        });
    }
    /*public void purchase (SharedPreferences prefs, SharedPreferences.Editor editor){

        balance = txt.valueOf(value)
        balance -= intCost;
        editor.putInt("COINS_VALUE", coins);
        counterTxt2.setText(txt.valueOf(coins));
        editor.apply();
        editor.commit();
    }
*/}