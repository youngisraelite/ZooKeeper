package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import androidx.core.app.NotificationCompat;
import android.app.NotificationManager;
import android.app.NotificationChannel;
import android.os.Build;
import org.w3c.dom.Text;

public class drivingScreen extends AppCompatActivity {
    private Button finish;
    private final String TAG = "main act";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        finish = (Button) findViewById(R.id.finish);

       /* NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "CHANNEL_ID")
                .setSmallIcon(R.drawable.coin)
                .setContentTitle("Oh no b")
                .setContentText("yo get back broadie")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        */

    //will be replaced with on finish timer code
        finish.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent in = new Intent(drivingScreen.this, finishScreen.class);
                startActivity(in);
            }
        });
    }


/* this has no real use it was just testing to c how the driving to crash screen works
    could be removed or not idk maybe it'll be useful
    protected void onStart() {
        super.onStart();


        Log.i(TAG, "on startizzle");
    }

    protected void onResume(){
        super.onResume();

        Log.i(TAG, "on resumizlle");
    }

    protected void onPause(){
        super.onPause();

        Log.i(TAG, "on pause that shit b");
    }

    protected void onStop(){
        super.onStop();


        Log.i(TAG, "on shtap");
    }

    public void onDestroy(){
        super.onDestroy();

        Log.i(TAG, "on destroy");
    }
    8
  */

    /*when the user leaves and returns to the driving screen ie "restarts" this method executes
    sending the user to the crash screen upon return to the app*/
    public void onRestart(){
        super.onRestart();

        Intent in = new Intent(drivingScreen.this, crash.class);
        startActivity(in);

        Log.i(TAG, "on restart");
    }

   /* private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string."channel_name");
            String description = getString(R.string."channel_description");
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("CHANNEL_ID", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    */



}