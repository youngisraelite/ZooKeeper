package com.example.myapplication;


import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;



import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;




public class breakScreen extends AppCompatActivity {
private Button breakToDriving;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.break_screen);

        breakToDriving = (Button) findViewById(R.id.skipKeep);

        //sends user back to driving screen on button click
        breakToDriving.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(breakScreen.this, drivingScreen.class);
                startActivity(in);
            }
        });

    }
}