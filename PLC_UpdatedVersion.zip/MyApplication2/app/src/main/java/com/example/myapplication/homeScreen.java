package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class homeScreen extends AppCompatActivity  {
    private Button toStoreButton;
    private Button begin;
    private Button toStat;
    private TextView counterTxt;
    int coins;
    String txt = "";
    private TextView coinTxt;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_screen);

        toStoreButton = (Button) findViewById(R.id.toStore);
        begin = (Button) findViewById(R.id.beginToDriveScreen);
        counterTxt = (TextView) findViewById(R.id.coinCounter);
        coinTxt = (TextView) findViewById(R.id.coinTxt);
        toStat = (Button) findViewById(R.id.homeToStat);

//idk wft this shit is; update: nvm it fucking works gets value from shared preference
//ima b honest theres prolly sum redundant code here but fuck it it works
        final SharedPreferences mSharedPreference= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        Integer value =(mSharedPreference.getInt("COINS_VALUE", 0));

       counterTxt.setText(txt.valueOf(value));
        Intent min = getIntent();
        coins = min.getIntExtra("t", 0);


     //sends user to stat screen on STAT button click
        toStat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(homeScreen.this, statScreen.class);
                startActivity(in);
            }
        });
        //sends user to driving screen on button click
        begin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(homeScreen.this, drivingScreen.class);
                startActivity(in);
            }
        });
        //sends user to store screen
        toStoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(homeScreen.this, storeScreen.class);
                startActivity(in);
            }
        });


    }


 /*   might do something later idk
    protected void onStart(){
        super.onStart();

    } */






}
